import { useEffect, useState } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { useCart } from "../cart/cartcontext";
import './products.css';

const Products = () => {
  const [products, setProducts] = useState([]);
  const { updateCart } = useCart(); // Get updateCart from context

  // Fetch products
  useEffect(() => {
    axios.get("http://localhost:5000/api/products")
      .then(response => setProducts(response.data))
      .catch(error => console.error("Error fetching products:", error));
  }, []);

  // Add to cart handler
  const addToCart = (productId) => {
    let cart = Cookies.get("cart") ? JSON.parse(Cookies.get("cart")) : {};
    cart[productId] = (cart[productId] || 0) + 1;
    Cookies.set("cart", JSON.stringify(cart), { expires: 1 });
    updateCart(cart);
    alert("Product added to cart!");
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center text-white mt-5 fw-bold">Popular</h1>
      <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 my-5">
        {products.map((product) => (
          <div className="col" key={product._id}>
            <div className="custom-card">
              <div className="custom-card-img">
                <img
                  src={`http://localhost:5000/uploads/${product.picture}`}
                  alt="Product"
                  className="img-fluid"
                />
              </div>
              <div className="custom-card-body">
                <span className="custom-badge">
                  {product.category ? product.category.title : "No Category"}
                </span>
                <h5 className="custom-title">{product.title}</h5>
                <p className="custom-desc">{product.description}</p>
                <div className="custom-meta">
                  <span>Gender: {product.gender}</span>
                  <span>Size: {product.size}</span>
                </div>
                <button
                  className="custom-btn"
                  onClick={() => addToCart(product._id)}
                >
                  PKR {product.price} • Add To Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Products;
