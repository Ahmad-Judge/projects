import React, { useState } from "react";
import { useCart } from "./cartcontext";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./checkout.css";

const Checkout = () => {
    const navigate = useNavigate();
    const { cart, updateCart } = useCart(); // Access the cart from context

    const [formData, setFormData] = useState({
        name: "",
        email: "",
        address: "",
        paymentMethod: "credit_card",
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!cart || Object.keys(cart).length === 0) {
            alert("Your cart is empty!");
            return;
        }

        // Calculate total
        const total = Object.values(cart).reduce((sum, item) => sum + item.price * item.quantity, 0);

        if (total === 0) {
            alert("Invalid total amount!");
            return;
        }

        const orderData = {
            ...formData,
            cart,
            total // ✅ Ensuring total is sent correctly
        };

        console.log("Order Data before sending:", orderData); // Debugging

        try {
            const response = await axios.post("http://localhost:5000/orders", orderData, {
                headers: { "Content-Type": "application/json" },
            });

            console.log("Order response:", response.data);
            alert("Order placed successfully!");

            updateCart({}); // Clear the cart
            navigate("/confirm", { state: response.data.order });
        } catch (error) {
            console.error("Order error:", error.response?.data || error.message);
            alert(error.response?.data?.error || "Failed to place order. Please try again.");
        }
    };

    return (
        <div className="checkout-container">
            <div className="checkout-card">
                <h2>Checkout</h2>
                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label>Name:</label>
                        <input type="text" name="name" value={formData.name} onChange={handleChange} required />
                    </div>

                    <div className="input-group">
                        <label>Email:</label>
                        <input type="email" name="email" value={formData.email} onChange={handleChange} required />
                    </div>

                    <div className="input-group">
                        <label>Address:</label>
                        <textarea name="address" value={formData.address} onChange={handleChange} required />
                    </div>

                    <div className="input-group">
                        <label>Payment Method:</label>
                        <select name="paymentMethod" value={formData.paymentMethod} onChange={handleChange} required>
                            <option value="credit_card">Credit Card</option>
                            <option value="paypal">PayPal</option>
                            <option value="cash_on_delivery">Cash on Delivery</option>
                        </select>
                    </div>

                    <button type="submit">Confirm Order</button>
                </form>
            </div>
        </div>
    );
};

export default Checkout;
