import React, { useEffect, useState } from "react";
import axios from "axios";
import "./AdminOrders.css";

const OrdersList = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await axios.get("http://localhost:5000/orders");
            setOrders(response.data);
        } catch (err) {
            setError("Failed to fetch orders. Please try again.");
            console.error("Error fetching orders:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleConfirmOrder = async (id) => {
        try {
            await axios.post(`http://localhost:5000/orders/confirm/${id}`);
            fetchOrders(); // Refresh order list
        } catch (err) {
            console.error("Error confirming order:", err);
            alert("Failed to confirm order.");
        }
    };

    const handleCancelOrder = async (id) => {
        try {
            await axios.post(`http://localhost:5000/orders/cancel/${id}`);
            fetchOrders(); // Refresh order list
        } catch (err) {
            console.error("Error canceling order:", err);
            alert("Failed to cancel order.");
        }
    };

    const handleDeleteOrder = async (id) => {
        try {
            await axios.delete(`http://localhost:5000/orders/${id}`);
            fetchOrders(); // Refresh order list
        } catch (err) {
            console.error("Error deleting order:", err);
            alert("Failed to delete order.");
        }
    };

    if (loading) return <p>Loading orders...</p>;
    if (error) return <p className="error">{error}</p>;

    return (
        <div className="orders-container">
            <h2>Order List</h2>
            {orders.length === 0 ? (
                <p>No orders found.</p>
            ) : (
                <table className="orders-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {orders.map((order) => (
                            <tr key={order._id}>
                                <td>{order._id}</td>
                                <td>{order.name}</td>
                                <td>{order.email}</td>
                                <td>${order.total.toFixed(2)}</td>
                                <td>{order.status}</td>
                                <td>
                                    {order.status === "Confirmed" || order.status === "Canceled" ? (
                                        <button
                                            className="delete-btn"
                                            onClick={() => handleDeleteOrder(order._id)}
                                        >
                                            Delete
                                        </button>
                                    ) : (
                                        <>
                                            <button
                                                className="confirm-btn"
                                                onClick={() => handleConfirmOrder(order._id)}
                                            >
                                                Confirm
                                            </button>
                                            <button
                                                className="cancel-btn"
                                                onClick={() => handleCancelOrder(order._id)}
                                            >
                                                Cancel
                                            </button>
                                        </>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default OrdersList;
