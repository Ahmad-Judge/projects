import { useState } from "react";
import axios from "axios";

const CategoryForm = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/categories", {
        title,
        description,
      });
      setMessage("Category created successfully!");
      setTitle("");
      setDescription("");
    } catch (error) {
      setMessage("Error creating category");
      console.error("Error:", error);
    }
  };

  return (
    <div className="container mt-4">
      <h4>Create New Category</h4>
      {message && <p className="alert alert-info">{message}</p>}
      <form onSubmit={handleSubmit} className="container">
        <div className="form-group">
          <label>Title</label>
          <input
            name="title"
            type="text"
            className="form-control"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Description</label>
          <textarea
            name="description"
            className="form-control"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          ></textarea>
        </div>
        <div className="form-group mt-3">
          <button type="submit" className="btn btn-info">Create Record</button>
        </div>
      </form>
    </div>
  );
};

export default CategoryForm;
