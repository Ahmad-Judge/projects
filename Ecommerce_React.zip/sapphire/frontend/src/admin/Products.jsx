import React, { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import axios from "axios";
import "./admin.css"; // Import your styles

const Products = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [searchParams, setSearchParams] = useSearchParams();

  // Get Query Params
  const page = parseInt(searchParams.get("page")) || 1;
  const searchQuery = searchParams.get("q") || "";
  const categoryFilter = searchParams.get("category") || "";
  const featuredFilter = searchParams.get("isFeatured") || "";
  const sortField = searchParams.get("sortField") || "title";
  const sortOrder = searchParams.get("sortOrder") || "asc";

  // Fetch Products from API
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/products`, {
          params: { page, q: searchQuery, category: categoryFilter, isFeatured: featuredFilter, sortField, sortOrder }
        });
        setProducts(res.data); 
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    fetchProducts();
  }, [page, searchQuery, categoryFilter, featuredFilter, sortField, sortOrder]);

  // Fetch Categories for Filtering
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/categories");
        setCategories(res.data);
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };
    fetchCategories();
  }, []);
  

  // Handle Delete Product
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      try {
        await axios.delete(`http://localhost:5000/api/products/${id}`);
        setProducts(products.filter(product => product._id !== id));
        
      } catch (error) {
        console.error("Error deleting product:", error);
      }
    }
  };

  return (
    <div className="container mt-4">
      <h3>Products</h3>

      {/* 🔻 Sorting Dropdown */}
      <div className="dropdown my-4">
        <button className="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
          Sort Products
        </button>
        <ul className="dropdown-menu">
          <li><Link className="dropdown-item" to={`?sortField=title&sortOrder=asc`}>Title (A-Z)</Link></li>
          <li><Link className="dropdown-item" to={`?sortField=title&sortOrder=desc`}>Title (Z-A)</Link></li>
          <li><Link className="dropdown-item" to={`?sortField=price&sortOrder=asc`}>Price (Low to High)</Link></li>
          <li><Link className="dropdown-item" to={`?sortField=price&sortOrder=desc`}>Price (High to Low)</Link></li>
        </ul>
      </div>

      {/* 🔍 Search & Filter Form */}
      <form className="row g-3">
        <div className="col-md-4">
          <input 
            type="text" 
            name="q" 
            className="form-control" 
            placeholder="Search by title or category..."
            value={searchQuery}
            onChange={(e) => setSearchParams({ q: e.target.value })}
          />
        </div>

        {/* Category Filter */}
        <div className="col-md-3">
          <select 
            name="category" 
            className="form-select"
            value={categoryFilter}
            onChange={(e) => setSearchParams({ category: e.target.value })}
          >
            <option value="">All Categories</option>
            {categories.map((cat) => (
              <option key={cat._id} value={cat._id}>{cat.title}</option>
            ))}
          </select>
        </div>

        {/* Featured Filter */}
        <div className="col-md-2">
          <select 
            name="isFeatured" 
            className="form-select"
            value={featuredFilter}
            onChange={(e) => setSearchParams({ isFeatured: e.target.value })}
          >
            <option value="">All Products</option>
            <option value="true">Featured</option>
            <option value="false">Not Featured</option>
          </select>
        </div>

        <div className="col-md-2">
          <button type="submit" className="btn btn-primary w-100">Filter</button>
        </div>
      </form>

      {/* 📄 Pagination */}
      <nav>
        <ul className="pagination">
          {page > 1 && (
            <li className="page-item">
              <Link className="page-link" to={`?page=${page - 1}`}>&laquo;</Link>
            </li>
          )}

          {Array.from({ length: totalPages }, (_, index) => (
            <li key={index} className={`page-item ${page === index + 1 ? "active" : ""}`}>
              <Link className="page-link" to={`?page=${index + 1}`}>{index + 1}</Link>
            </li>
          ))}

          {page < totalPages && (
            <li className="page-item">
              <Link className="page-link" to={`?page=${page + 1}`}>&raquo;</Link>
            </li>
          )}
        </ul>
      </nav>

      {/* ➕ Create Product */}
      <Link to="/admin/productform" className="btn btn-info">Create New Product</Link>

      {/* 🛍 Product Table */}
      <h3 className="mt-5">Products</h3>
      <table className="table table-hover table-striped table-responsive-md">
        <thead className="table-dark">
          <tr>
            <th>_id</th>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            <th>Size</th>
            <th>Gender</th>
            <th>Is Featured</th>
            <th>Image</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product._id}>
              <td>{product._id}</td>
              <td>{product.category ? product.category.title : "No Category"}</td>
              <td>{product.description}</td>
              <td>PKR {product.price}</td>
              <td>{product.size}</td>
              <td>{product.gender}</td>
              <td>{product.isFeatured ? "Yes" : "No"}</td>
              <td>
                <img src={`http://localhost:5000/uploads/${product.picture}`} alt="Product" width="100px" className="img-fluid rounded" />
              </td>
              <td>
              <Link to={`/admin/productEditForm/${product._id}`} className="btn btn-warning btn-sm">Edit</Link>

                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(product._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Products;
