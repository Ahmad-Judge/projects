import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ProductForm = () => {
  const [categories, setCategories] = useState([]);
  const [formData, setFormData] = useState({
    category: "",
    description: "This is IPhone desc",
    price: 5000,
    isFeatured: false,
    gender: "men",
    size: "small",
  });
  const [file, setFile] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/categories")
      .then(response => setCategories(response.data))
      .catch(error => console.error("Error fetching categories:", error));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      data.append(key, value);
    });
    if (file) {
      data.append("file", file);
    }

    try {
      await axios.post("http://localhost:5000/api/products", data);
      navigate("/admin/products"); // ✅ Navigate to homepage
    } catch (error) {
      console.error("Error creating product:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h4>Create New Product</h4>

      <form onSubmit={handleSubmit} className="container">

        {/* Category Dropdown */}
        <div className="form-group">
          <label>Category</label>
          <select
            name="category"
            className="form-control"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          >
            <option value="">Select Category</option>
            {categories.map(category => (
              <option key={category._id} value={category._id}>
                {category.title}
              </option>
            ))}
          </select>
        </div>

        {/* Description */}
        <div className="form-group">
          <label>Description</label>
          <textarea
            name="description"
            className="form-control"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          />
        </div>

        {/* Price */}
        <div className="form-group">
          <label>Price</label>
          <input
            name="price"
            type="number"
            className="form-control"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
          />
        </div>

        {/* Picture Upload */}
        <div className="form-group">
          <label>Picture</label>
          <input
            name="file"
            type="file"
            className="form-control"
            onChange={(e) => setFile(e.target.files[0])}
          />
        </div>

        {/* Featured Checkbox */}
        <div className="form-group my-3">
          <label>Featured?</label>
          <input
            name="isFeatured"
            type="checkbox"
            className="form-check-input"
            checked={formData.isFeatured}
            onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
          />
        </div>

        {/* Gender Dropdown */}
        <div className="form-group">
          <label>Gender</label>
          <select
            name="gender"
            className="form-control"
            value={formData.gender}
            onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
          >
            <option value="men">Men</option>
            <option value="women">Women</option>
            <option value="children">Children</option>
          </select>
        </div>

        {/* Size Dropdown */}
        <div className="form-group">
          <label>Size</label>
          <select
            name="size"
            className="form-control"
            value={formData.size}
            onChange={(e) => setFormData({ ...formData, size: e.target.value })}
          >
            <option value="small">Small</option>
            <option value="medium">Medium</option>
            <option value="large">Large</option>
            <option value="xl">XL</option>
            <option value="xxl">XXL</option>
            <option value="xxxl">XXXL</option>
          </select>
        </div>

        {/* Submit Button */}
        <div className="form-group">
          <button className="btn btn-info" type="submit">Create Record</button>
        </div>

      </form>
    </div>
  );
};

export default ProductForm;
